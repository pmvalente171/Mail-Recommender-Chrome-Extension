# Assistente DALM: backend specification

This document specifies the HTTP backend for the **Assistente DALM**, a Chrome extension that adds an optional AI helper to the Gmail reply box of staff in a university's Academic Division (DALM, FCT NOVA). It is written for whoever builds the backend, human or coding agent, and is self-contained: you do not need the extension's repository to implement it.

The extension is finished up to the point of calling these endpoints. It currently answers from a built-in mock. Your backend replaces that mock, so the request and response shapes below are **exactly what the extension sends and parses today** (for `/list`) or what it will parse next (for `/generate`, `/config`, `/log`). Do not rename fields.

The existing backend (`agent/server.py` + `DALMRecommender`, a multi-step LLM and retrieval pipeline that answers in European Portuguese, served on `http://localhost:4000` with `POST /recommend`) is the starting point. Reuse its retrieval, sources and model access. `POST /recommend` is no longer called by the extension and can stay or go.

---

## 1. What the product does

The extension is a **research probe** for a study on how AI can help staff without taking away their freedom not to use it. The flow in Gmail:

1. Staff open an email thread and start a reply. A bar offers help. Nothing is read until they click **Preparar a lista**.
2. The extension reads the thread, removes personal data in the browser, and calls **`POST /list`**. The backend answers with:
   - a one-sentence restatement of what the email asks;
   - the **points** the reply must cover, each with the information the backend could **not** find (`needs`) and a suggestion of **who should handle it** (the assistant or the person);
   - tasks the person must do **outside the email** (in other systems or with other people).
3. For each point the person decides who handles it. They type any missing values into the panel. These values **never leave the browser**.
4. Clicking **Gerar os pontos do assistente** calls **`POST /generate`** with only the points assigned to the assistant. The backend returns one paragraph per point, as text with named **slots** where the missing values go. The extension fills the slots locally and inserts the text into the reply.
5. The person reads the text, edits it, confirms each point, and sends the email themselves.

Everything is in **European Portuguese** (pt-PT).

---

## 2. Rules the backend must respect

These come from the study design and are not negotiable.

1. **Never invent facts.** Numbers of places, grades, dates, deadlines, fees, names of offices or people, rules: if a fact is not in a source you actually retrieved, do not write it. Put it in `needs` (in `/list`) and as a **slot** (in `/generate`). A blank the person fills is correct behaviour; a plausible guess is a failure.
   **Be conservative with what past answers say.** Past answers can be out of date. Never assert from them that something does **not** exist or apply (e.g. "the course doesn't exist"); make it a need or a point for the person. Deadlines, academic years and amounts taken from answers tagged `TEMPORAL_*`, `REG_AMOUNT` or `REG_EDITAL` become needs unless clearly current. Once sources carry dates, answers older than **24 months** count as unconfirmed.
2. **Say what you used.** `/list` returns the names of the sources actually used (`sources`). Never list a source you did not use.
3. **The AI does not act or decide.** It never certifies, graduates or confirms that a student completed something, and it never claims to have done anything in CLIP, SinGAP, Gesdoc or any other system. Points that involve such judgements are suggested as the **person's** (`"owner": "user"`), and actions in those systems go in `outside`.
4. **Personal data.** The thread arrives already redacted (section 3), and so does every text in `/log` (the extension redacts it the same way). Do not try to recover redacted values. Thread text and other content (the `/list` and `/generate` calls, and `/log`'s `content`) are stored **only** for participants with `text_logging_consent` (section 6), only in the study files (section 7.1), and never in server logs or anywhere else.
5. **Keys stay server-side.** The model API key lives in the backend only. The model must be EU-hosted or one the university has agreed to.
6. **Language and register.** pt-PT (not pt-BR: "você", "registo", "contacto", "equipa", "facto"), formal and courteous, as a university academic office writes.

---

## 3. What the extension sends: the redacted thread

`thread` is plain text built from the **expanded** messages of the Gmail conversation, oldest first, in this format:

```
De: [nome] <[email]>
Data: 13/10/2026, 10:42

Exmos. Srs.,
...message body...

---

De: [nome] <[email]>
Data: 14/10/2026, 09:05

...next message...
```

Messages are separated by a line with `---`. Messages Gmail shows collapsed are not included. Gmail's hidden quoted history ("…") is not included either.

Before sending, the browser replaces personal data with these **labels**:

| Label | Replaces |
|---|---|
| `[email]` | Email addresses |
| `[IBAN]` | IBANs (e.g. `PT50 0002 …`) |
| `[NIB]` | 21-digit Portuguese NIBs |
| `[telefone]` | Phone numbers (+351 or 9 digits starting with 2 or 9) |
| `[NIF]` | Other 9-digit numbers (tax numbers) |
| `[n.º de aluno]` | Standalone 5–6 digit numbers (student numbers, and sometimes other numbers) |
| `[nome]` | The senders' names as Gmail shows them, and each part of those names |

Known gaps: other people's names in the text, and names spelled differently in signatures, are **not** removed. Postal codes, years and course codes are left as they are.

How to treat the labels:
- Treat them as opaque: "the sender's student number", "an email address".
- **Never write a label into a reply.** If the answer needs one of these values (for example to quote the student's number back), make it a `need` and a slot, so the person types it.
- Do not address the sender by name. The greeting is added by the extension (section 5.4).

---

## 4. `POST /list`

Called when the person clicks **Preparar a lista** (or automatically when a reply opens, if they turned on "Preparar sempre").

### Request

```json
{
  "thread": "De: [nome] <[email]>\nData: …\n\nExmos. Srs., …",
  "ticket": "3f1c…64 hex chars…",
  "participant": "p07"
}
```

| Field | Type | Notes |
|---|---|---|
| `thread` | string | Redacted thread, section 3. Can be several thousand characters. |
| `ticket` | string | SHA-256 (hex) of Gmail's thread ID. Stable per conversation, so use it to correlate requests. It is not reversible to the thread. |
| `participant` | string, optional | Pseudonymous study ID (e.g. `p01`), set per installation in the extension's `config.local.json`. Development builds have none, so accept its absence (and store nothing for the study without it). |

### Response (200)

```json
{
  "in_scope": true,
  "request_summary": "um encarregado de educação quer saber se a Licenciatura em Análise e Engenharia de Dados abre vagas em 2026/27 e quais as condições de acesso.",
  "points": [
    {
      "id": "c2",
      "title": "Vagas",
      "desc": "dizer quantas vagas há no concurso de 2026/27.",
      "needs": [ {
        "key": "vagas", "label": "N.º de vagas",
        "question": "Quantas vagas tem o curso no concurso de 2026/27?",
        "type": "number", "hint": "ex.: 25",
        "options": []
      } ],
      "owner": "ai",
      "source_ids": ["s1"]
    },
    {
      "id": "c3",
      "title": "Condições de acesso",
      "desc": "indicar as provas de ingresso e a nota mínima.",
      "needs": [
        { "key": "provas", "label": "Provas de ingresso" },
        { "key": "nota", "label": "Nota mínima de candidatura" }
      ],
      "owner": "ai",
      "source_ids": ["s1", "s2"]
    },
    {
      "id": "c5",
      "title": "Site",
      "desc": "lamentar que a informação ainda não esteja no nosso site.",
      "needs": [],
      "owner": "user",
      "source_ids": []
    }
  ],
  "outside": [
    { "id": "o1", "text": "Pedir à equipa do site que publique a página do curso." }
  ],
  "steps": ["Li o email", "Percebi o pedido", "Procurei a informação nas respostas anteriores da DALM"],
  "sources": [
    "Resposta anterior da DALM: «Como posso aceder à Licenciatura em Análise e Engenharia de Dados?»",
    "Resposta anterior da DALM: «Quais as condições de acesso à licenciatura?»"
  ],
  "source_details": [
    { "id": "s1", "question": "Como posso aceder à Licenciatura em Análise e Engenharia de Dados?",
      "excerpt": "…verbatim snippet of the staff reply, at most 200 characters…", "date": null },
    { "id": "s2", "question": "Quais as condições de acesso à licenciatura?",
      "excerpt": "…", "date": null }
  ]
}
```

| Field | Type | Rules |
|---|---|---|
| `in_scope` | boolean | `false` if the email is not something the Academic Division answers (spam, personal, another service). Then return `points: []` and `outside: []`, and use `request_summary` to say briefly what the email is. The extension does not show a special message for this yet. It shows the summary and an empty list. |
| `request_summary` | string | **One sentence**, starting in lowercase, completing "O pedido: …". Describe who asks what, without personal data. Shown verbatim. |
| `points` | array | What the reply must cover, in the order the reply should follow. **1–4 points** (enforced). Merge points that cover the same idea; no points that restate the question or describe the system's own uncertainty. Do not include greeting, thanks or sign-off. |
| `points[].id` | string | Unique within the list. Short, e.g. `c1`, `c2`. Sent back to `/generate`. |
| `points[].title` | string | 1–3 everyday words, capitalised: "Vagas", "Condições de acesso". Shown as the point's one-line label. |
| `points[].desc` | string | At most ~12 words. Starts in lowercase with an infinitive verb and ends with a full stop: "dizer quantas vagas…", "indicar…", "explicar…", "lamentar…". Shown when the point is opened. |
| `points[].needs` | array | Facts the reply needs that you **could not find in your sources**, or found only in old or time-sensitive answers (rule 1). Empty if you found everything or the point needs no facts. **At most ~4 needs in the whole list**: if more facts are uncertain, give the point to the person (`"owner": "user"`) instead of adding blanks. |
| `needs[].key` | string | **Must match `^[a-z0-9_]+$`** (it is used as an HTML id). Keys are **global to the list**: if two points need the same fact, use the same key and the person types it once. Different facts need different keys. |
| `needs[].label` | string | **At most 4 words**, pt-PT, capitalised. Used inside the email's brackets while the value is missing: `[N.º de vagas]`, `[Email de recuperação]`. |
| `needs[].question` | string | The need as **one plain pt-PT question ending in "?"**, specific enough to answer without rereading the email; no redaction labels. Shown as the heading of the field in the panel: "Quantas vagas tem o curso no concurso de 2026/27?". |
| `needs[].type` | `"text"` \| `"email"` \| `"date"` \| `"number"` \| `"url"` | Kind of field. Default `"text"`. `"number"` only for counts (places, instalments); amounts are `"text"` ("697 €"). |
| `needs[].hint` | string, optional | Format example, **set server-side from `type`**, never by the model: email → "ex.: nome@fct.unl.pt", date → "ex.: 15/09/2026", url → "ex.: https://…", number → "ex.: 25". Omitted for `"text"`. |
| `needs[].options` | array, optional | Up to 3 candidate values **found in the retrieved sources** but not confirmed: `[{ "value": "…", "source_id": "s1", "time_sensitive": false }]`. Kept only if `value` appears verbatim (whitespace/case-normalised) in the `excerpt` of that source in `source_details`, matches the need's `type`, and `source_id` is one of the point's own `source_ids`. `value` is display text, never normalised (no ISO dates, no added years). Never personal data. `time_sensitive: true` when the source is tagged `TEMPORAL_*`/`REG_AMOUNT`/`REG_EDITAL` or the value names an earlier academic year. Omitted or `[]` when none. The extension never preselects an option. |
| `points[].owner` | `"ai"` or `"user"` | Your **suggestion** of who handles the point. The person can switch it. If missing or anything else, the extension treats it as `"user"`. See the guidelines below. |
| `outside` | array | Tasks the person must do **outside the email**: in CLIP, SinGAP, Gesdoc, or by asking a colleague or service. Each `{ "id": "o1", "text": "…" }`, `text` an imperative sentence in pt-PT. Never things the AI can do. Can be empty. |
| `steps` | array of strings | What you did, past tense, first person, pt-PT. Shown under "Ver passos". The extension adds the line "Não encontrei N informações" itself, so do not include it. |
| `points[].source_ids` | array of strings | Ids from `source_details` of the retrieved answers that support this point. `[]` when no source supports it (then it is mostly needs). |
| `sources` | array of strings | Human-readable names of the sources actually used, at most 3, each under ~100 characters, e.g. "Resposta anterior da DALM: «…»". Shown as "Fontes: …". Same order as `source_details`. Empty if none. |
| `source_details` | array | One object per source: `id` (`s1`, `s2`…), `question` (the matched past question), `excerpt` (**verbatim** snippet of the staff's past reply, at most 200 characters, never a paraphrase), `date` (ISO date of that reply, or `null` while the index has no dates). Shown when a point is opened, so people can judge where it came from. Never include ticket ids. |

**Guidelines for `owner`:**
- `"ai"` for **recurring, factual** points answered from documents: dates, places, requirements, procedures, where to apply, which form to use. This is what staff most want help with.
- `"user"` for points that need **judgement, personal tone or accountability**: apologies, exceptions, anything about a specific student's situation or record, decisions, complaints. Also **always** `"user"` for certifying, confirming completion, graduation, or checking whether someone did something. Staff explicitly refused to hand these to AI.
- When in doubt, `"user"`. The study is about freedom of choice, so the person opting in is better than the AI over-reaching.

---

## 5. `POST /generate`

Called when the person clicks **Gerar os pontos do assistente (N)** or **Gerar outra versão**. The extension wiring for this is the next build step, so implement exactly this contract.

### Request

```json
{
  "thread": "…same redacted thread as /list…",
  "ticket": "3f1c…",
  "participant": "p07",
  "request_summary": "um encarregado de educação quer saber se …",
  "points": [
    { "id": "c2", "title": "Vagas", "desc": "dizer quantas vagas há no concurso de 2026/27.",
      "needs": [ { "key": "vagas", "label": "N.º de vagas" } ] },
    { "id": "c3", "title": "Condições de acesso", "desc": "indicar as provas de ingresso e a nota mínima.",
      "needs": [ { "key": "provas", "label": "Provas de ingresso" }, { "key": "nota", "label": "Nota mínima" } ] }
  ],
  "context_points": [
    { "id": "c5", "title": "Site", "desc": "lamentar que a informação ainda não esteja no nosso site." }
  ],
  "previous": null,
  "instruction": null
}
```

| Field | Type | Notes |
|---|---|---|
| `thread`, `ticket`, `participant` | | As in `/list`. |
| `request_summary` | string | From `/list`. |
| `points` | array | **Only** the points to write now: assigned to the assistant, not yet written, not done. The person may have **edited** titles and descriptions, or **added** points (ids like `n1718…`, often with empty `needs`). Follow the text as given, not your original list. |
| `context_points` | array | The other points of the reply (written by the person). **Do not write them.** Use them only to avoid repeating or contradicting what the person covers. |
| `previous` | array or null | For **Gerar outra versão**: the paragraphs you returned last time for these points, in the response format below. Write a **different** wording, with the same facts and the same slots. `null` on a first generation. |
| `instruction` | string or null | Reserved for a future "Não é isto?" correction. Currently always `null`. If present, follow it. |

The values the person typed for the needs are **never sent to `/generate`**. You will not know them, so write around slots. (For consenting participants they reach the study log, redacted, through `/log`: section 7.)

### Response (200)

```json
{
  "paragraphs": [
    { "point": "c2", "segments": [
      { "text": "No Concurso Nacional de Acesso 2026/27, o curso tem " },
      { "slot": "vagas" },
      { "text": " vagas." }
    ] },
    { "point": "c3", "segments": [
      { "text": "As provas de ingresso são " },
      { "slot": "provas" },
      { "text": " e a nota mínima de candidatura é de " },
      { "slot": "nota" },
      { "text": " valores." }
    ] }
  ]
}
```

| Rule | |
|---|---|
| One paragraph per requested point | Same order as `points`, `point` = the point's `id`. Never a paragraph for a `context_points` id. |
| `segments` | A list of `{ "text": "…" }` and `{ "slot": "key" }`. Concatenated, they form one paragraph of plain text. |
| Plain text only | No HTML, no Markdown, no bullet characters, no line breaks inside a paragraph. |
| Slots | `slot` must be one of **that point's** `needs[].key`. Every need of the point should appear as a slot exactly where its value belongs, written so the sentence reads correctly once the value is filled in. Never put a redaction label (`[nome]` …) or a made-up value in a `text` segment. |
| No greeting or sign-off | The extension adds "Caro(a) …", the thanks line and the signature from a per-user template. Do not write them. |
| Facts | Only from sources (rule 1). If a fact is missing and is not one of the point's needs, either write the paragraph without it or say plainly that the information will follow ("Enviaremos essa informação logo que esteja disponível."). Never guess. |
| Length | 1–3 sentences per point. The reply is meant to be read and edited. |

The extension inserts the slots as bracketed placeholders, e.g. `[N.º de vagas]`, when the person has not typed a value, and replaces them locally when they do.

---

## 6. `GET /config`

```
GET /config?participant=p07
```

```json
{ "phase": 2, "generate_enabled": true, "text_logging_consent": false }
```

| Field | Notes |
|---|---|
| `phase` | Study phase. Example design: phase 1 = list only, phase 2 = full assistant. Final design is set by the researcher. |
| `generate_enabled` | If `false`, the extension hides all generation buttons (list-only phase). |
| `text_logging_consent` | Whether this participant consented to text being stored. Default `false`. It controls both the storage of their `/list` and `/generate` calls (request and response) and whether their `/log` events keep `content`. The extension also leaves `content` out of events when it is `false`. |

Keep the participant-to-phase mapping in a config file the researcher can edit without code changes (`study_config.json`). Unknown or missing participant: return phase 2 with `generate_enabled: true` and `text_logging_consent: false`.

The extension asks when Gmail loads and again each time the panel opens. Until it answers, or if it fails, the extension uses those same defaults, so a failure never stores text.

---

## 7. `POST /log`

The extension queues study events and sends them in batches: every 15 s, right after a reply is sent, and when the Gmail tab is hidden or closed. Store them append-only and return `204`. If a batch fails, the extension keeps it and sends it again with the next one, so events can arrive late (use `ts`, not arrival time). The extension sends no events from a build without a participant ID.

```json
{
  "events": [
    { "event": "list_requested", "participant": "p07", "ticket": "3f1c…", "phase": 2, "ts": "2026-10-14T15:02:11.204Z" },
    { "event": "owner_changed", "participant": "p07", "ticket": "3f1c…", "phase": 2, "ts": "…", "point": "c4", "to": "user", "suggested": "ai" },
    { "event": "point_edited", "participant": "p07", "ticket": "3f1c…", "phase": 2, "ts": "…", "point": "c3", "field": "title",
      "content": { "before": "Prazo", "after": "Prazo de candidatura" } }
  ]
}
```

Every event has `event`, `participant`, `ticket`, `phase` and `ts` (ISO 8601). `ticket` is the same hash sent to `/list`, so events, `/list` and `/generate` calls about one conversation can be joined.

**Text goes only in `content`.** All text an event carries (titles, values, paragraphs, the final reply) is inside one top-level object, `content`. Every other field is metadata.
- The extension adds `content` only when `/config` says `text_logging_consent: true`, and redacts it first, like the thread (section 3): patterns plus the senders' names.
- The server must also drop `content` (and any legacy `text`, `thread`, `value` or `body` field) for participants without consent.

| Event | Extra fields | `content` (consent only) |
|---|---|---|
| `bar_shown`, `list_requested`, `assistant_declined`, `panel_hidden`, `assistant_reopened`, `steps_expanded`, `guide_opened` | none | |
| `list_shown` | `n_points`, `n_needs` (distinct keys) | (the list itself is in the stored `/list` call) |
| `owner_changed` | `point`, `to` (`"ai"`/`"user"`), `suggested` (the backend's owner; `null` for an added point) | |
| `value_entered` | `key`, `source` (`"typed"`: logged when the person pauses ~2 s; `"option"`: a suggestion picked), `empty` (bool: the field was cleared) | `{ value }` |
| `point_done`, `point_undone` | `point`, `ai` (bool: the assistant wrote its section), `via` (`"marked"`: Marcar como feito/Desfazer; `"slot"`: the person typed in, or emptied, their slot; `"deleted"`: its section was deleted from the email, undone only), `seconds_since_generated` (since its section was placed; `null` if none) | `{ text }`: the section as it stood (for `"slot"`, at the first keystroke: the final text is in `reply_sent`) |
| `outside_done`, `outside_undone` | `item` (an `outside` id) | |
| `generate_clicked` | `points` (ids sent to `/generate`), `slots` (ids of the person's points given a slot), `n_done_before` | (stored with the `/generate` call) |
| `regenerate_clicked` | `points` | (stored with the `/generate` call) |
| `ai_text_removed` | `points` | |
| `point_edited` | `point`, `field` (`"title"`/`"desc"`), one event per changed field when "Concluir" is clicked | `{ before, after }` |
| `point_added` | `point` (id like `n1718…`) | `{ title, desc }` |
| `point_deleted` | `point` | `{ title, desc }` |
| `list_edited` | `added`, `deleted`, `renamed` (counts, at "Concluir"; only if something changed) | |
| `pref_prepare_always` | `value` (bool; `ticket` is `null`) | |
| `reply_sent` | `how` (`"click"`, `"button_key"`, `"shortcut"`: Ctrl/⌘+Enter), `had_list`, `edit_distance_per_point` (assistant's point id → characters changed, Levenshtein, from its text with the person's values filled in to the final text), `placeholders_left` | `{ ai_text: {id: text}, final_text: {id: text}, final_reply }`. `final_text` includes the person's slots. `final_reply` is the reply as sent, with Gmail's signature but **without the quoted earlier messages**. |

`reply_sent` is detected when Enviar is clicked (or the shortcut pressed), before Gmail sends; a send Gmail then refuses (e.g. no recipient) is still logged. Accept unknown event names and fields, and store them as they are.

### 7.1 Stored data

| File | Who | What |
|---|---|---|
| `events.jsonl` | every participant | `/log` events, append-only. `content` only for participants with consent. |
| `interactions.jsonl` | consenting participants only | every `/list` and `/generate` call that carries `participant`: the full request (redacted thread, ticket, and for `/generate` the points as edited, `context_points`, `previous`), the full response, the model and the duration. |

Nothing is stored for requests without a participant ID (development builds) or for unknown participants beyond their metadata events. Server logs keep one timing line per request and no email content.

---

## 8. Errors, timing and transport

- **Base URL:**
  - **Production:** `https://113-30-149-134.sslip.io`, hosted on a small EU VPS. It uses HTTPS with a Let's Encrypt certificate; sslip.io maps the name to the server's IP, 113.30.149.134.
  - **Development:** `http://localhost:4000`.
  - The extension takes the URL from its build config (`config.local.json` → `build/config.js`; without that file it uses localhost). Both origins are in its `host_permissions`.
- **Auth:** every request to `/list`, `/generate`, `/config` and `/log` sends the header `X-API-Key: <key>`.
  - A missing or wrong key gets `401 {"error": "missing or invalid X-API-Key"}`. The extension treats it like any other error and logs "Invalid API key" or "Missing API key" in its service worker console.
  - `GET /health` is open: it answers `{"status": "ok"}` without a key, and adds the model details when a valid key is sent.
  - Each installation (one per PC) has its own key, so one can be revoked alone. Keys live only in the extension's gitignored `config.local.json` and on the server, and never in either repo.
- **Calls come from the extension's service worker**, not from the Gmail page. The backend's origin is in the extension's `host_permissions`, so CORS is not enforced. The server allows it anyway, including the `X-API-Key` header.
- **Errors:** any non-2xx response makes the extension show "Não foi possível contactar o assistente." with a retry button. Return a JSON body `{ "error": "…" }` with a useful message for the logs. Use `400` for malformed requests (e.g. a `/generate` point id with a slot key not in its needs), `401` for a missing or invalid key, and `500` for failures.
- **Timing:** the server gives up after **120 s** (`REQUEST_BUDGET_S`). The extension animates progress steps while it waits and gives up after **150 s**, so the server's timeout fires first and returns a proper error. Current latency with Amalia (backend v0.13): an in-scope `/list` takes ~15–25 s, `/generate` ~5 s. `/list` blocks the first view of the panel, so it benefits most from being faster.
- **Validate your own output** before returning it: required fields present, need keys match `^[a-z0-9_]+$`, every slot is a need of its point, no paragraph for an unrequested point, no redaction labels in `text`. If the model's output fails, retry once, then return `500`.

---

## 9. How to test against the extension

1. Run the backend on `http://localhost:4000` (with `API_KEYS` set to test the auth), or use the production server.
2. In the extension repo, copy `config.example.json` to `config.local.json`, set `backendUrl`, this PC's `apiKey` and its `participantId` (`p01`, `p02`… for participants; a name not in `study_config.json`, e.g. `dev`, for testing, so nothing lands in the study data), and check that `MOCK_BACKEND = false` in `public/ServiceWorker.js`. Run `npm run build` (it prints which URL it built for, and whether a key is included) and reload the extension in `chrome://extensions`. Without `config.local.json`, the build calls `http://localhost:4000` with no key.
3. Open a thread in Gmail, start a reply, click **Preparar a lista**. To see exactly what the backend received, open `chrome://extensions` → the extension's **service worker** console.

Quick checks with curl:

Add `-H 'X-API-Key: <key>'` to each call when the server has keys set.

```bash
curl -s localhost:4000/list -H 'Content-Type: application/json' -d '{
  "thread": "De: [nome] <[email]>\nData: 13/10/2026\n\nExmos. Srs., pretendo saber se a Licenciatura em Análise e Engenharia de Dados abre vagas em 2026/27 e quais as condições de acesso. Não encontro a informação no vosso site. Cumprimentos, [nome]",
  "ticket": "test"
}'

curl -s localhost:4000/generate -H 'Content-Type: application/json' -d '{
  "thread": "…", "ticket": "test", "request_summary": "…",
  "points": [ { "id": "c2", "title": "Vagas", "desc": "dizer quantas vagas há no concurso de 2026/27.", "needs": [ { "key": "vagas", "label": "N.º de vagas" } ] } ],
  "context_points": [], "previous": null, "instruction": null
}'
```

### Acceptance checklist

- [ ] `/list` returns every field in section 4, in pt-PT, with need keys matching `^[a-z0-9_]+$` and unique per fact across the list.
- [ ] Facts not found in sources appear as `needs`, never as invented values. Try an email about a course or year with no documents.
- [ ] Points about certifying, completion or a student's record are suggested as `"owner": "user"`. Actions in CLIP, SinGAP or Gesdoc are in `outside`.
- [ ] An off-topic email returns `in_scope: false` with empty `points` and `outside`.
- [ ] `/generate` returns one paragraph per requested point, in order, plain text, slots only from that point's needs, no greeting or sign-off, no redaction labels.
- [ ] `/generate` with `previous` returns different wording with the same slots.
- [ ] Edited and added points are written as edited. `context_points` are not written.
- [ ] Thread text and `content` are stored only for participants with `text_logging_consent`, only in `events.jsonl`/`interactions.jsonl`, never in server logs. For other participants `/log` stores metadata only.
- [ ] The model API key is only on the server.
- [ ] `/list`, `/generate`, `/config` and `/log` answer `401` without a valid `X-API-Key`; `/health` answers without one.

---

## Revision history

- **2026-10-16, after the heuristic evaluation** (agreed by Pedro and both sessions; plan in `docs/REDESIGN_PLAN.md`): `/list` returns 1–4 points with short titles and descriptions; at most ~4 needs per list, with labels phrased as what to fill in; conservative use of past answers (rule 1); new additive fields `points[].source_ids` and `source_details`. Nothing existing was removed or renamed.
- **2026-10-19, "Falta saber" round 2** (agreed by Pedro and both sessions; `docs/REDESIGN_PLAN.md`, Round 2): `needs[]` gains `question`, `type`, `hint` (server-side from `type`) and `options` (verbatim-grounded, with `time_sensitive`); `label` becomes ≤4 words and is used for the brackets in the email. Additive: nothing removed or renamed.
- **2026-11-19, public server and access keys** (approved by Pedro; backend v0.13): production base URL `https://113-30-149-134.sslip.io` on an EU VPS, with `http://localhost:4000` kept for development. `/list`, `/generate`, `/config` and `/log` require `X-API-Key` and answer `401` without a valid one; `/health` stays open. One key per installation, kept out of both repos. Server timeout 120 s, client 150 s. Section 9 now describes the extension's `config.local.json`.
- **2026-11-19, study content logging** (approved by Pedro, who confirmed the consent form and ethics approval cover storing email text; backend v0.14): for participants with `text_logging_consent`, the backend stores every `/list` and `/generate` call (`interactions.jsonl`) and `/log` keeps text, always inside one `content` object, redacted by the extension like the thread. The final reply is logged without the quoted earlier messages. The extension now sends `participant` (set per installation), reads `/config` (consent, hiding generation) and sends `/log` in batches. New events: `point_edited`, `point_added`, `point_deleted`, `outside_done`/`outside_undone`; new fields on `value_entered`, `point_done`/`point_undone`, `generate_clicked` and `reply_sent`. Section 7.1 lists the stored files. Typed values now reach the study log (never `/generate`).
